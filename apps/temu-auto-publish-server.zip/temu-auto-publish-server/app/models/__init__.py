"""
@PURPOSE: 数据库模型包
@OUTLINE:
  - user: 用户模型
"""

from .user import User

__all__ = ["User"]

