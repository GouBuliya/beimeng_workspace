"""
@PURPOSE: 用户管理模块包
@OUTLINE:
  - router: 用户管理路由
  - schemas: 用户管理相关的 Pydantic 模型
  - service: 用户管理业务逻辑
"""

