"""
@PURPOSE: Temu Auto Publish 认证服务器应用包
@OUTLINE:
  - 提供认证服务器的 FastAPI 应用入口
"""

